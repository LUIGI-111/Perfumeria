document.addEventListener("DOMContentLoaded", async function () {
const perfumeList = document.getElementById("perfume-list");
const userName = document.getElementById("user-name");
const logoutButton = document.getElementById("logout-button");

// Mostrar nombre del usuario si está guardado en sessionStorage
const user = sessionStorage.getItem("user");
if (user) {
    const parsedUser = JSON.parse(user);
    userName.textContent = `Hola, ${parsedUser.email}`;
}

// Cerrar sesión
logoutButton.addEventListener("click", () => {
    sessionStorage.removeItem("user");
    localStorage.removeItem("userId");
    window.location.href = "login.html";
});

// Obtener perfumes desde el backend
async function loadPerfumes() {
    const res = await fetch("http://localhost:3000/api/perfumes");
    const data = await res.json();

    /*perfumeList.innerHTML = "Cargando perfumes..."; // mostrar loading

    if (data.success && data.perfumes.length > 0) {
    data.perfumes.forEach(perfume => {
        const card = document.createElement("div");
        card.classList.add("perfume-card");

        card.innerHTML = `
        <img src="${perfume.imagenUrl || '../img/default.png'}" alt="${perfume.nombre_perfume}" class="perfume-img">
        <h3>${perfume.nombre_perfume}</h3>
        <p class="marca">${perfume.marca}</p>
        <p class="descripcion">${perfume.description_perfume || ''}</p>
        <p class="precio">$${perfume.precio}</p>
        <button class="btn-primary add-cart" data-id="${perfume.perfumes_id}">Agregar al carrito</button>
        <button class="btn-secondary add-fav" data-id="${perfume.perfumes_id}">❤️ Favorito</button>
        `;

        perfumeList.innerHTML += card.outerHTML;
    });
    } else {
    perfumeList.innerHTML = "<p>No hay perfumes disponibles en este momento.</p>";
    }*/

    

    const contenedor = document.getElementById("contenedor-perfumes");
    data.forEach(perfume => {
        const card = `
        <div class="perfume-card">
        <img src="${perfume.imagenUrl || '../img/default.png'}" alt="${perfume.nombre_perfume}" class="perfume-img">
        <h3>${perfume.nombre_perfume}</h3>
        <p class="marca">${perfume.marca}</p>
        <p class="descripcion">${perfume.description_perfume || ''}</p>
        <p class="precio">$${perfume.precio}</p>
        <button class="btn-primary add-cart" data-id="${perfume.perfumes_id}">Agregar al carrito</button>
        <button class="btn-secondary add-fav" data-id="${perfume.perfumes_id}">❤️ Favorito</button>
        </div>

        `;

        contenedor.innerHTML += card;
    });

} 
loadPerfumes();

// Delegación de eventos para carrito y favoritos
perfumeList.addEventListener("click", async (e) => {
    const userId = localStorage.getItem("userId");
    if (!userId) {
    showToast("Debes iniciar sesión para continuar");
    return;
    }

    // Agregar al carrito
    if (e.target.classList.contains("add-cart")) {
    const perfumeId = e.target.dataset.id;

    try {
        const res = await fetch("http://localhost:3000/api/carrito", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            fk_user_id: userId,
            fk_perfume_id: perfumeId,
            cantidad: 1
        })
        });

        const data = await res.json();
        if (data.success) {
        showToast("Producto agregado al carrito");
        } else {
        showToast("Error al agregar al carrito");
        }
    } catch (error) {
        console.error("Error:", error);
        showToast("Error de conexión con el servidor");
    }
    }

    // Agregar a favoritos
    if (e.target.classList.contains("add-fav")) {
    const perfumeId = e.target.dataset.id;

    try {
        const res = await fetch("http://localhost:3000/api/favoritos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            fk_user_id: userId,
            fk_perfume_id: perfumeId
        })
        });

        const data = await res.json();
        if (data.success) {
        showToast("Perfume agregado a favoritos");
        } else {
        showToast("Error al agregar a favoritos");
        }
    } catch (error) {
        console.error("Error:", error);
        showToast("Error de conexión con el servidor");
    }
    }
});

// Función para mostrar mensajes tipo toast
function showToast(message) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3000);
}
});